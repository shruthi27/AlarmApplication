package com.taradov.alarmme;
 
import android.app.Activity;
import android.os.Bundle;
 
public class About extends Activity
{
  @Override
  protected void onCreate(Bundle bundle)
  {
    super.onCreate(bundle);
    setContentView(R.layout.about);
  }
}

